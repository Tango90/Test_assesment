from datetime import datetime, timedelta
import random
from app.models import Grid, GridRegion, GridNode, Measure
from app.database import SessionLocal, engine, Base

Base.metadata.create_all(bind=engine)

db = SessionLocal()

# Initialize sample data
grids = [Grid(name=f"Grid{i+1}") for i in range(3)]
regions = []
nodes = []
for grid in grids:
    db.add(grid)
    db.flush()
    for i in range(3):
        region = GridRegion(name=f"Region{i+1}_{grid.name}", grid_id=grid.id)
        db.add(region)
        db.flush()
        for j in range(3):
            node = GridNode(name=f"Node{j+1}_{region.name}", region_id=region.id)
            db.add(node)
            db.flush()
            nodes.append(node)

db.commit()

# Insert 1-week hourly timeseries with evolution
base_time = datetime.utcnow().replace(minute=0, second=0, microsecond=0)
for node in nodes:
    for h in range(24 * 7):
        timestamp = base_time + timedelta(hours=h)
        for evolution_step in range(3):
            collected_at = base_time + timedelta(hours=h - 6 + evolution_step)
            value = 100 - evolution_step + random.random()
            db.add(Measure(node_id=node.id, timestamp=timestamp, collected_at=collected_at, value=value))
db.commit()
db.close()
