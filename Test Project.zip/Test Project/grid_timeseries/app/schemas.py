from pydantic import BaseModel
from datetime import datetime

class MeasureOut(BaseModel):
    node_id: int
    timestamp: datetime
    collected_at: datetime
    value: float

    class Config:
        orm_mode = True