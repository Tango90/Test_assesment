from fastapi import FastAPI, Depends
from sqlalchemy.orm import Session
from datetime import datetime
from .database import get_db
from .crud import get_latest_measures, get_measures_by_collected_time
from .schemas import MeasureOut

app = FastAPI()

@app.get("/latest-values/", response_model=list[MeasureOut])
def latest_values(start: datetime, end: datetime, db: Session = Depends(get_db)):
    return get_latest_measures(db, start, end)

@app.get("/collected-values/", response_model=list[MeasureOut])
def collected_values(start: datetime, end: datetime, collected_at: datetime, db: Session = Depends(get_db)):
    return get_measures_by_collected_time(db, start, end, collected_at)