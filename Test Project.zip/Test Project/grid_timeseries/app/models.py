from sqlalchemy import Column, Integer, String, Float, ForeignKey, DateTime
from sqlalchemy.orm import relationship
from .database import Base

class Grid(Base):
    __tablename__ = "grids"
    id = Column(Integer, primary_key=True)
    name = Column(String, unique=True)

class GridRegion(Base):
    __tablename__ = "grid_regions"
    id = Column(Integer, primary_key=True)
    name = Column(String)
    grid_id = Column(Integer, ForeignKey("grids.id"))

class GridNode(Base):
    __tablename__ = "grid_nodes"
    id = Column(Integer, primary_key=True)
    name = Column(String)
    region_id = Column(Integer, ForeignKey("grid_regions.id"))

class Measure(Base):
    __tablename__ = "measures"
    id = Column(Integer, primary_key=True)
    node_id = Column(Integer, ForeignKey("grid_nodes.id"))
    timestamp = Column(DateTime)
    collected_at = Column(DateTime)
    value = Column(Float)
