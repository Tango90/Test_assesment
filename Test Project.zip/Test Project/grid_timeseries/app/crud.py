from sqlalchemy.orm import Session
from sqlalchemy import func, and_
from .models import Measure

def get_latest_measures(db: Session, start, end):
    subquery = (
        db.query(
            Measure.timestamp,
            func.max(Measure.collected_at).label("latest_collected_at")
        )
        .filter(Measure.timestamp.between(start, end))
        .group_by(Measure.timestamp)
        .subquery()
    )

    return (
        db.query(Measure)
        .join(subquery, and_(
            Measure.timestamp == subquery.c.timestamp,
            Measure.collected_at == subquery.c.latest_collected_at
        ))
        .all()
    )

def get_measures_by_collected_time(db: Session, start, end, collected_at):
    return (
        db.query(Measure)
        .filter(
            Measure.timestamp.between(start, end),
            Measure.collected_at == collected_at
        )
        .all()
    )