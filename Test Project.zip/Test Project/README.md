# Grid Time Series API

This project simulates evolving time series data for Grid Nodes and provides APIs to query latest or historical values.

## Features
- Hierarchical structure: Grid → GridRegion → GridNode
- Measures stored with `timestamp` and `collected_at`
- API to get:
  - Latest values for a timestamp range
  - Specific collected values

## Setup
```bash
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

Start PostgreSQL locally and create the `grid` database. Then run:
```bash
python scripts/generate_data.py
uvicorn app.main:app --reload
```

## API Example
- `/latest-values/?start=2025-07-01T00:00:00&end=2025-07-07T00:00:00`
- `/collected-values/?start=2025-07-01T00:00:00&end=2025-07-07T00:00:00&collected_at=2025-07-03T08:00:00`
